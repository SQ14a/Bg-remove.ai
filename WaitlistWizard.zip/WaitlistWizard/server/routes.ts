import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertWaitlistSchema, insertBlogPostSchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";

export function registerRoutes(app: Express): Server {
  app.post("/api/waitlist", async (req, res) => {
    try {
      const data = insertWaitlistSchema.parse(req.body);
      
      const isRegistered = await storage.isEmailRegistered(data.email);
      if (isRegistered) {
        return res.status(400).json({
          message: "This email is already registered",
        });
      }
      const entry = await storage.addToWaitlist(data);
      res.status(201).json(entry);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({
          message: fromZodError(error).message,
        });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.post("/api/process-image", async (req, res) => {
    try {
      const data = insertImageProcessSchema.parse(req.body);
      const process = await storage.createImageProcess(data);

      // In a real application, we would process the image here
      // For now, we'll simulate processing by returning the same image
      const updatedProcess = await storage.updateImageProcess(process.id, data.originalImage);

      res.status(201).json(updatedProcess);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({
          message: fromZodError(error).message,
        });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.get("/api/process-image/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const process = await storage.getImageProcess(id);

      if (!process) {
        return res.status(404).json({ message: "Image process not found" });
      }

      res.json(process);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Blog routes
  app.get("/api/blog-posts", async (_req, res) => {
    try {
      const posts = await storage.getBlogPosts();
      res.json(posts);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/blog-posts/:slug", async (req, res) => {
    try {
      const post = await storage.getBlogPostBySlug(req.params.slug);
      if (!post) {
        return res.status(404).json({ message: "Blog post not found" });
      }
      res.json(post);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/blog-posts", async (req, res) => {
    try {
      const data = insertBlogPostSchema.parse(req.body);
      const post = await storage.createBlogPost(data);
      res.status(201).json(post);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({
          message: fromZodError(error).message,
        });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
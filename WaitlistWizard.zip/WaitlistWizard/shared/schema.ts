import { pgTable, text, serial, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const waitlist = pgTable("waitlist", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertWaitlistSchema = createInsertSchema(waitlist)
  .pick({ email: true })
  .extend({
    email: z.string().email("Please enter a valid email address"),
  });

export type InsertWaitlist = z.infer<typeof insertWaitlistSchema>;
export type Waitlist = typeof waitlist.$inferSelect;

export const blogPosts = pgTable("blog_posts", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  content: text("content").notNull(),
  excerpt: text("excerpt").notNull(),
  coverImage: text("cover_image"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  metadata: jsonb("metadata"),
});

export const insertBlogPostSchema = createInsertSchema(blogPosts)
  .pick({ title: true, content: true, excerpt: true, coverImage: true })
  .extend({
    title: z.string().min(1, "Title is required"),
    content: z.string().min(1, "Content is required"),
    excerpt: z.string().min(1, "Excerpt is required"),
    coverImage: z.string().optional(),
  });

export type InsertBlogPost = z.infer<typeof insertBlogPostSchema>;
export type BlogPost = typeof blogPosts.$inferSelect;

export const imageProcesses = pgTable("image_processes", {
  id: serial("id").primaryKey(),
  originalImage: text("original_image").notNull(),
  processedImage: text("processed_image"),
  status: text("status").notNull().default('pending'),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  metadata: jsonb("metadata")
});

export const insertImageProcessSchema = createInsertSchema(imageProcesses)
  .pick({ originalImage: true })
  .extend({
    originalImage: z.string().min(1, "Image is required"),
  });

export type InsertImageProcess = z.infer<typeof insertImageProcessSchema>;
export type ImageProcess = typeof imageProcesses.$inferSelect;
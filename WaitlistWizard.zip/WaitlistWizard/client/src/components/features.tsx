import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Zap, Shield, Sparkles, Image, Monitor, Palette, 
  FileStack, Crown, Cpu, Clock, Save, Layout 
} from "lucide-react";

const features = [
  {
    title: "100% Automated",
    description: "Powered by AI for instant background removal",
    icon: Zap,
    premium: false
  },
  {
    title: "8K Resolution Support",
    description: "Process ultra-high resolution images up to 8K",
    icon: Monitor,
    premium: true
  },
  {
    title: "AI Edge Detection",
    description: "Advanced AI-powered edge detection for perfect results",
    icon: Sparkles,
    premium: true
  },
  {
    title: "Secure Processing",
    description: "Enterprise-grade security with end-to-end encryption",
    icon: Shield,
    premium: true
  },
  {
    title: "Batch Processing",
    description: "Process multiple images simultaneously",
    icon: FileStack,
    premium: true
  },
  {
    title: "Priority Processing",
    description: "Skip the queue with premium priority processing",
    icon: Crown,
    premium: true
  },
  {
    title: "Advanced AI Models",
    description: "Access to latest AI models for better results",
    icon: Cpu,
    premium: true
  },
  {
    title: "Instant Processing",
    description: "Process images in under 3 seconds",
    icon: Clock,
    premium: true
  },
  {
    title: "Multiple Formats",
    description: "Export in PNG, JPEG, WebP, and more",
    icon: Save,
    premium: true
  },
  {
    title: "Smart Cropping",
    description: "AI-powered smart cropping and composition",
    icon: Layout,
    premium: true
  },
  {
    title: "Multiple Formats",
    description: "Support for PNG, JPEG, and other common formats",
    icon: Image,
    premium: false
  },
  {
    title: "Color Perfect",
    description: "Preserves original colors with 100% accuracy",
    icon: Palette,
    premium: false
  },
];

export default function Features() {
  return (
    <section className="py-24 bg-background" id="features">
      <div className="container px-4 mx-auto">
        <div className="text-center mb-12">
          <span className="text-primary text-sm font-medium bg-primary/10 px-4 py-2 rounded-full mb-4 inline-block">
            Premium Features
          </span>
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Professional-Grade Background Removal
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Experience the most advanced AI-powered background removal tool with
            premium features designed for professionals.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className={`relative ${feature.premium ? 'border-primary/50' : ''}`}>
                {feature.premium && (
                  <span className="absolute -top-3 -right-3 bg-primary text-primary-foreground text-xs px-2 py-1 rounded-full">
                    Premium
                  </span>
                )}
                <CardContent className="p-6">
                  <feature.icon className={`w-10 h-10 mb-4 ${feature.premium ? 'text-primary' : 'text-muted-foreground'}`} />
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <div className="inline-flex items-center gap-8 p-4 bg-primary/5 rounded-lg">
            <div className="text-left">
              <h3 className="text-xl font-semibold mb-2">Upgrade to Premium</h3>
              <p className="text-muted-foreground">
                Get access to all premium features and process unlimited images
              </p>
            </div>
            <button className="bg-primary text-primary-foreground px-6 py-3 rounded-lg font-medium hover:bg-primary/90 transition-colors">
              Go Premium
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { ArrowDown, Crown, Sparkles, Zap } from "lucide-react";

const stats = [
  { number: "8K", label: "Max Resolution", icon: Crown },
  { number: "3 sec", label: "Processing Time", icon: Zap },
  { number: "99.9%", label: "Accuracy", icon: Sparkles },
];

export default function Hero() {
  return (
    <div className="relative min-h-[80vh] flex items-center justify-center bg-gradient-to-b from-background to-primary/5">
      <div className="container px-4 py-32 mx-auto text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <div className="flex items-center justify-center gap-2 mb-6">
            <Crown className="h-6 w-6 text-primary" />
            <span className="text-sm font-medium bg-primary/10 text-primary px-3 py-1 rounded-full">
              Professional Grade AI
            </span>
          </div>

          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-primary via-primary/80 to-primary/60 bg-clip-text text-transparent">
            Remove Background from Images
            <br />
            in Just 3 Seconds
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
            Experience professional-grade background removal with our advanced AI technology.
            Now supporting up to 8K resolution with perfect edge detection.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button
              size="lg"
              className="text-lg"
              onClick={() => {
                const uploadSection = document.getElementById("image-processor");
                uploadSection?.scrollIntoView({ behavior: "smooth" });
              }}
            >
              Try Premium Features
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-lg"
              onClick={() => {
                const howItWorks = document.getElementById("how-it-works");
                howItWorks?.scrollIntoView({ behavior: "smooth" });
              }}
            >
              How It Works
            </Button>
          </div>

          {/* Stats Section */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-3xl mx-auto">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 + index * 0.1 }}
                className="text-center"
              >
                <div className="flex justify-center mb-2">
                  <stat.icon className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-3xl font-bold text-primary mb-2">{stat.number}</h3>
                <p className="text-muted-foreground">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="flex justify-center"
        >
          <ArrowDown className="h-8 w-8 text-primary animate-bounce" />
        </motion.div>
      </div>
    </div>
  );
}
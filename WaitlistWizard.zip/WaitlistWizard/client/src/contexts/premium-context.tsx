import { createContext, useContext, useState, useEffect } from 'react';

interface PremiumContextType {
  isPremium: boolean;
  setPremiumStatus: (status: boolean) => void;
  showUpgradeModal: () => void;
}

const PremiumContext = createContext<PremiumContextType | undefined>(undefined);

export function PremiumProvider({ children }: { children: React.ReactNode }) {
  const [isPremium, setIsPremium] = useState(false);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    // In a real app, this would check the user's subscription status
    const checkPremiumStatus = async () => {
      try {
        const response = await fetch('/api/check-premium');
        const data = await response.json();
        setIsPremium(data.isPremium);
      } catch (error) {
        console.error('Error checking premium status:', error);
        setIsPremium(false);
      }
    };

    checkPremiumStatus();
  }, []);

  const setPremiumStatus = (status: boolean) => {
    setIsPremium(status);
  };

  const showUpgradeModal = () => {
    setShowModal(true);
  };

  return (
    <PremiumContext.Provider value={{ isPremium, setPremiumStatus, showUpgradeModal }}>
      {children}
      {showModal && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50">
          <div className="fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 sm:rounded-lg">
            <h2 className="text-2xl font-bold">Upgrade to Premium</h2>
            <p className="text-muted-foreground">
              Get access to all premium features including:
              <ul className="mt-4 space-y-2">
                <li>• Batch image processing</li>
                <li>• 8K resolution support</li>
                <li>• Priority processing</li>
                <li>• Advanced AI models</li>
              </ul>
            </p>
            <div className="flex justify-end gap-4 mt-6">
              <button
                onClick={() => setShowModal(false)}
                className="px-4 py-2 text-sm rounded-md border"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  // Implement upgrade flow
                  window.location.href = '/pricing';
                }}
                className="px-4 py-2 text-sm font-medium text-primary-foreground bg-primary rounded-md hover:bg-primary/90"
              >
                Upgrade Now
              </button>
            </div>
          </div>
        </div>
      )}
    </PremiumContext.Provider>
  );
}

export function usePremium() {
  const context = useContext(PremiumContext);
  if (context === undefined) {
    throw new Error('usePremium must be used within a PremiumProvider');
  }
  return context;
}

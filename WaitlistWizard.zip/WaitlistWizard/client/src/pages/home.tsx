import Hero from "@/components/hero";
import Features from "@/components/features";
import HowItWorks from "@/components/how-it-works";
import ImageProcessor from "@/components/image-processor";

export default function Home() {
  return (
    <div className="min-h-screen">
      <Hero />
      <ImageProcessor />
      <HowItWorks />
      <Features />
    </div>
  );
}
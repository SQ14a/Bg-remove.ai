import { waitlist, type Waitlist, type InsertWaitlist } from "@shared/schema";
import { imageProcesses, type ImageProcess, type InsertImageProcess } from "@shared/schema";
import { blogPosts, type BlogPost, type InsertBlogPost } from "@shared/schema";

export interface IStorage {
  addToWaitlist(entry: InsertWaitlist): Promise<Waitlist>;
  isEmailRegistered(email: string): Promise<boolean>;
  createImageProcess(process: InsertImageProcess): Promise<ImageProcess>;
  getImageProcess(id: number): Promise<ImageProcess | undefined>;
  updateImageProcess(id: number, processedImage: string): Promise<ImageProcess | undefined>;

  // Blog related methods
  createBlogPost(post: InsertBlogPost): Promise<BlogPost>;
  getBlogPosts(): Promise<BlogPost[]>;
  getBlogPostBySlug(slug: string): Promise<BlogPost | undefined>;
  updateBlogPost(id: number, post: Partial<InsertBlogPost>): Promise<BlogPost | undefined>;
  deleteBlogPost(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private waitlist: Map<number, Waitlist>;
  private processes: Map<number, ImageProcess>;
  private blogPosts: Map<number, BlogPost>;
  currentId: number;

  constructor() {
    this.waitlist = new Map();
    this.processes = new Map();
    this.blogPosts = new Map();
    this.currentId = 1;
  }

  async addToWaitlist(entry: InsertWaitlist): Promise<Waitlist> {
    const id = this.currentId++;
    const waitlistEntry: Waitlist = {
      ...entry,
      id,
      createdAt: new Date(),
    };
    this.waitlist.set(id, waitlistEntry);
    return waitlistEntry;
  }

  async isEmailRegistered(email: string): Promise<boolean> {
    return Array.from(this.waitlist.values()).some(
      (entry) => entry.email === email,
    );
  }

  async createImageProcess(process: InsertImageProcess): Promise<ImageProcess> {
    const id = this.currentId++;
    const imageProcess: ImageProcess = {
      ...process,
      id,
      status: 'pending',
      processedImage: null,
      createdAt: new Date(),
      metadata: null
    };
    this.processes.set(id, imageProcess);
    return imageProcess;
  }

  async getImageProcess(id: number): Promise<ImageProcess | undefined> {
    return this.processes.get(id);
  }

  async updateImageProcess(id: number, processedImage: string): Promise<ImageProcess | undefined> {
    const process = this.processes.get(id);
    if (!process) return undefined;

    const updatedProcess = {
      ...process,
      processedImage,
      status: 'completed'
    };
    this.processes.set(id, updatedProcess);
    return updatedProcess;
  }

  async createBlogPost(post: InsertBlogPost): Promise<BlogPost> {
    const id = this.currentId++;
    const slug = post.title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '');

    const blogPost: BlogPost = {
      ...post,
      id,
      slug,
      createdAt: new Date(),
      updatedAt: new Date(),
      metadata: null
    };
    this.blogPosts.set(id, blogPost);
    return blogPost;
  }

  async getBlogPosts(): Promise<BlogPost[]> {
    return Array.from(this.blogPosts.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getBlogPostBySlug(slug: string): Promise<BlogPost | undefined> {
    return Array.from(this.blogPosts.values())
      .find(post => post.slug === slug);
  }

  async updateBlogPost(id: number, post: Partial<InsertBlogPost>): Promise<BlogPost | undefined> {
    const existingPost = this.blogPosts.get(id);
    if (!existingPost) return undefined;

    const updatedPost = {
      ...existingPost,
      ...post,
      updatedAt: new Date()
    };
    this.blogPosts.set(id, updatedPost);
    return updatedPost;
  }

  async deleteBlogPost(id: number): Promise<boolean> {
    return this.blogPosts.delete(id);
  }
}

export const storage = new MemStorage();
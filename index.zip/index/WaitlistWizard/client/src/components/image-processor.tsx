import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Upload,
  Image as ImageIcon,
  Loader2,
  FileWarning,
  Crown,
} from "lucide-react";
import { usePremium } from "@/contexts/premium-context";

const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB for premium
const SUPPORTED_FORMATS = ["image/jpeg", "image/png", "image/webp"];
const EXPORT_FORMATS = ["PNG", "JPEG", "WebP"];
const RESOLUTIONS = ["Original", "4K", "8K"];

export default function ImageProcessor() {
  const { isPremium, showUpgradeModal } = usePremium();
  const { toast } = useToast();
  const [selectedImages, setSelectedImages] = useState<string[]>([]);
  const [processedImages, setProcessedImages] = useState<string[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [exportFormat, setExportFormat] = useState("PNG");
  const [resolution, setResolution] = useState("Original");

  const mutation = useMutation({
    mutationFn: async (files: File[]) => {
      if (!isPremium && files.length > 1) {
        throw new Error("Batch processing is a premium feature");
      }

      for (const file of files) {
        if (file.size > MAX_FILE_SIZE) {
          throw new Error("File size should not exceed 10MB");
        }

        if (!SUPPORTED_FORMATS.includes(file.type)) {
          throw new Error("Please upload valid image files (JPEG, PNG, or WebP)");
        }
      }

      // Simulate upload progress
      const progressInterval = setInterval(() => {
        setUploadProgress((prev) => Math.min(prev + 10, 90));
      }, 100);

      // Convert images to base64
      const base64Images = await Promise.all(
        files.map(
          (file) =>
            new Promise<string>((resolve) => {
              const reader = new FileReader();
              reader.onloadend = () => resolve(reader.result as string);
              reader.readAsDataURL(file);
            })
        )
      );

      const responses = await Promise.all(
        base64Images.map((image) =>
          apiRequest("POST", "/api/process-image", {
            originalImage: image,
            format: exportFormat,
            resolution,
          })
        )
      );

      clearInterval(progressInterval);
      setUploadProgress(100);

      return responses.map((res) => res.json());
    },
    onSuccess: (data) => {
      setProcessedImages(data.map((d) => d.processedImage));
      toast({
        title: "Success!",
        description: `${data.length} image${
          data.length > 1 ? "s have" : " has"
        } been processed successfully.`,
      });
      setTimeout(() => setUploadProgress(0), 1000);
    },
    onError: (error: Error) => {
      if (error.message.includes("premium")) {
        showUpgradeModal();
      } else {
        toast({
          variant: "destructive",
          title: "Error",
          description: error.message,
        });
      }
      setUploadProgress(0);
    },
  });

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    const files = Array.from(e.dataTransfer.files);
    handleFiles(files);
  };

  const handleFiles = (files: File[]) => {
    Promise.all(
      files.map(
        (file) =>
          new Promise<string>((resolve) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result as string);
            reader.readAsDataURL(file);
          })
      )
    ).then((images) => {
      setSelectedImages(images);
      mutation.mutate(files);
    });
  };

  return (
    <section id="image-processor" className="py-24 bg-background">
      <div className="container px-4 mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto"
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Remove Background</h2>
            <p className="text-muted-foreground">
              Upload your images and we'll remove the background instantly
            </p>
          </div>

          {/* Settings */}
          <div className="flex gap-4 mb-8 justify-center">
            <Select
              value={exportFormat}
              onValueChange={setExportFormat}
              disabled={!isPremium}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Export Format" />
              </SelectTrigger>
              <SelectContent>
                {EXPORT_FORMATS.map((format) => (
                  <SelectItem key={format} value={format}>
                    {format}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select
              value={resolution}
              onValueChange={setResolution}
              disabled={!isPremium}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Resolution" />
              </SelectTrigger>
              <SelectContent>
                {RESOLUTIONS.map((res) => (
                  <SelectItem key={res} value={res}>
                    {res}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Upload Area */}
            <Card
              className={`relative aspect-square transition-colors ${
                isDragging ? "border-primary border-2" : ""
              }`}
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
            >
              <CardContent className="h-full p-6 flex flex-col items-center justify-center">
                <input
                  type="file"
                  multiple={isPremium}
                  accept={SUPPORTED_FORMATS.join(",")}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                  onChange={(e) => {
                    const files = Array.from(e.target.files || []);
                    if (files.length) handleFiles(files);
                  }}
                  disabled={mutation.isPending}
                />
                {selectedImages.length > 0 ? (
                  <div className="grid grid-cols-2 gap-2 w-full h-full">
                    {selectedImages.map((image, index) => (
                      <img
                        key={index}
                        src={image}
                        alt={`Original ${index + 1}`}
                        className="w-full h-full object-contain"
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center">
                    <Upload className="w-12 h-12 mb-4 mx-auto text-primary" />
                    <p className="text-muted-foreground mb-2">
                      {isPremium
                        ? "Drop your images here or click to upload"
                        : "Drop an image here or click to upload"}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Supports JPEG, PNG, WebP up to{" "}
                      {isPremium ? "10MB" : "5MB"}
                    </p>
                    {!isPremium && (
                      <div className="mt-4 flex items-center gap-2 text-sm text-primary">
                        <Crown className="h-4 w-4" />
                        <span>Upgrade for batch processing</span>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Result Area */}
            <Card className="aspect-square">
              <CardContent className="h-full p-6 flex flex-col items-center justify-center">
                {mutation.isPending ? (
                  <div className="text-center w-full">
                    <Loader2 className="w-12 h-12 mb-4 mx-auto animate-spin text-primary" />
                    <p className="text-muted-foreground mb-4">
                      Processing image{selectedImages.length > 1 ? "s" : ""}...
                    </p>
                    <Progress value={uploadProgress} className="w-full" />
                  </div>
                ) : processedImages.length > 0 ? (
                  <div className="grid grid-cols-2 gap-2 w-full h-full">
                    {processedImages.map((image, index) => (
                      <img
                        key={index}
                        src={image}
                        alt={`Processed ${index + 1}`}
                        className="w-full h-full object-contain"
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center">
                    <ImageIcon className="w-12 h-12 mb-4 mx-auto text-muted-foreground" />
                    <p className="text-muted-foreground">
                      Processed image{isPremium ? "s" : ""} will appear here
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {processedImages.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-8 text-center"
            >
              <Button
                size="lg"
                onClick={() => {
                  processedImages.forEach((image, index) => {
                    const link = document.createElement("a");
                    link.href = image;
                    link.download = `processed-image-${index + 1}.${exportFormat.toLowerCase()}`;
                    link.click();
                  });
                }}
              >
                Download Result{processedImages.length > 1 ? "s" : ""}
              </Button>
            </motion.div>
          )}

          {/* Error display */}
          {mutation.error && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="mt-4 p-4 bg-destructive/10 rounded-lg flex items-center gap-2 text-destructive"
            >
              <FileWarning className="h-5 w-5" />
              <p>{mutation.error.message}</p>
            </motion.div>
          )}
        </motion.div>
      </div>
    </section>
  );
}
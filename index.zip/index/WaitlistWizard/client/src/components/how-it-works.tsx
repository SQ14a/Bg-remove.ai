import { motion } from "framer-motion";
import { Upload, Wand2, Download, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";

const steps = [
  {
    title: "Upload Image",
    description: "Select and upload any image from your device. Supports JPEG, PNG, and WebP formats up to 5MB.",
    icon: Upload,
    details: ["Drag & drop supported", "Instant upload", "No account required"],
  },
  {
    title: "AI Processing",
    description: "Our advanced AI technology automatically detects and removes the background with perfect precision.",
    icon: Wand2,
    details: ["Smart object detection", "Edge refinement", "5-second processing"],
  },
  {
    title: "Download Result",
    description: "Get your processed image instantly in high resolution, ready to use anywhere.",
    icon: Download,
    details: ["High-quality output", "Transparent background", "Multiple format options"],
  },
];

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="py-24 bg-primary/5">
      <div className="container px-4 mx-auto">
        <div className="text-center mb-16">
          <span className="text-primary text-sm font-medium bg-primary/10 px-4 py-2 rounded-full mb-4 inline-block">
            Simple Process
          </span>
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Remove Background in 3 Easy Steps
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Our AI-powered tool makes it incredibly simple to remove backgrounds from your images.
            No technical skills required!
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 max-w-5xl mx-auto">
          {steps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.2 }}
              viewport={{ once: true }}
              className="relative"
            >
              {/* Step number */}
              <div className="absolute -top-4 -left-4 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold">
                {index + 1}
              </div>

              {/* Content */}
              <div className="bg-background rounded-lg p-6 h-full shadow-sm">
                <div className="mb-6 inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10">
                  <step.icon className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">{step.title}</h3>
                <p className="text-muted-foreground mb-4">{step.description}</p>

                {/* Feature list */}
                <ul className="space-y-2">
                  {step.details.map((detail, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <CheckCircle2 className="w-4 h-4 text-primary" />
                      {detail}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Connector line for desktop */}
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-1/2 -right-6 w-12 border-t-2 border-dashed border-primary/30" />
              )}
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <Button
            size="lg"
            onClick={() => {
              const uploadSection = document.getElementById("image-processor");
              uploadSection?.scrollIntoView({ behavior: "smooth" });
            }}
          >
            Try It Now
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
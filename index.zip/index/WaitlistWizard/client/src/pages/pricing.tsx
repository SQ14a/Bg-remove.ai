import { motion } from "framer-motion";
import { Check, Crown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";

const plans = [
  {
    name: "Free",
    price: "$0",
    description: "Perfect for casual users",
    features: [
      "Process up to 5 images per day",
      "Basic AI model",
      "Up to 5MB per image",
      "JPEG & PNG support",
      "Standard processing speed",
    ],
    buttonText: "Get Started",
    isPremium: false,
  },
  {
    name: "Premium",
    price: "$9.99",
    period: "per month",
    description: "For professionals and power users",
    features: [
      "Unlimited image processing",
      "Advanced AI models",
      "Up to 10MB per image",
      "8K resolution support",
      "Batch processing",
      "Priority processing queue",
      "Multiple export formats",
      "Smart cropping",
      "24/7 Premium support",
    ],
    buttonText: "Upgrade Now",
    isPremium: true,
  },
];

export default function PricingPage() {
  return (
    <div className="min-h-screen py-24">
      <div className="container px-4 mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <span className="text-primary text-sm font-medium bg-primary/10 px-4 py-2 rounded-full mb-4 inline-block">
            Pricing Plans
          </span>
          <h1 className="text-4xl font-bold mb-4">Choose Your Plan</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Select the perfect plan for your needs. Upgrade anytime to access premium features.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.2 }}
            >
              <Card className={`relative ${plan.isPremium ? 'border-primary' : ''}`}>
                {plan.isPremium && (
                  <div className="absolute -top-4 -right-4">
                    <span className="bg-primary text-primary-foreground text-sm px-3 py-1 rounded-full flex items-center gap-2">
                      <Crown className="w-4 h-4" />
                      Premium
                    </span>
                  </div>
                )}
                <CardHeader className="text-center pb-8">
                  <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                  <div className="mb-2">
                    <span className="text-4xl font-bold">{plan.price}</span>
                    {plan.period && (
                      <span className="text-muted-foreground">/{plan.period}</span>
                    )}
                  </div>
                  <p className="text-muted-foreground">{plan.description}</p>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-4 mb-8">
                    {plan.features.map((feature) => (
                      <li key={feature} className="flex items-center gap-3">
                        <Check className={`w-5 h-5 ${plan.isPremium ? 'text-primary' : 'text-muted-foreground'}`} />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button
                    size="lg"
                    className="w-full"
                    variant={plan.isPremium ? "default" : "outline"}
                  >
                    {plan.buttonText}
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
